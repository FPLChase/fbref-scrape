import bs4 as bs
import urllib.request
import pandas as pd
import os
import pickle
import time


def import_data(league_name, urls, trim_len):
    cur_dir = os.getcwd()
    path = cur_dir + '/{}_data'.format(league_name)

    # Create dir to contain league_name data
    try:
        os.mkdir(path)
    except OSError:
        print ("Directory %s already exists" % path)
    else:
        print ("Successfully created the directory %s " % path)

    # Write pickle to track which matches have been scraped
    if os.path.isfile(path + '/hrefs.pickle'):
        pickle_in = open(path + '/hrefs.pickle', 'rb')
        hrefs = pickle.load(pickle_in)
    else:
        hrefs = []

    # Scrape each fixture url to find links to matches
    for season_index, url in enumerate(urls):
        path = cur_dir + '/{}_data/'.format(league_name) + str(season_index + 2017) + '_' + str(season_index + 18)
        try:
            os.mkdir(path)
        except OSError:
            print("Directory %s already exists" % path)
        else:
            print("Successfully created the directory %s " % path)

        sauce = urllib.request.urlopen(url).read()
        soup = bs.BeautifulSoup(sauce, 'lxml')

        table = soup.find('table')

        links = table.find_all('a')
        text = [link.text for link in links]
        indices = [i for i, x in enumerate(text) if x == 'Match Report' and text[i-2] != '']
        # Scrape each stats page, passing if already scraped
        for links in [links[i] for i in indices]:
            url = 'https://fbref.com' + links['href']
            if url.split('/')[-1].replace('-', '_') not in path and links['href'] not in hrefs:
                dfs = pd.read_html(url)


                """
                dfs =       [0] hteamlineup,
                            [1] ateam lineup,
                            [2] basic team stats (DO NOT USE),
                
                    hteam   {
                                [3] summary,
                                [4] passing
                                [5] pass types,
                                [6] defensive actions
                                [7] possession
                                [8] miscellaneous stats
                                [9] gk
                            }
                    
                    
                            
                    ateam   {
                                [10] summary,
                                [11] passing
                                [12] pass types,
                                [13] defensive actions
                                [14] possession
                                [15] miscellaneous stats
                                [16] gk
                            }
                        
                """
                if len(dfs) > 10:
                    teams = (dfs[2].columns[0][0], dfs[2].columns[1][0])
                    formations = [None, None]

                    # Format squad dfs
                    for i in range(2):
                        formations[i] = dfs[i].columns[0].split(' ')[-1]
                        dfs[i].columns = ['#', 'player']
                        dfs[i]['start'] = [True] * 11 + [False] * (len(dfs[i]) - 11)
                        dfs[i] = dfs[i].drop(11).set_index('#')

                    def reframe_squad_table(dfs_indices, col_names):
                        for i in dfs_indices:
                            df_ = dfs[i][:-1]
                            df_ = pd.DataFrame(data={col: df_[df_.columns[ii]] for ii, col in enumerate(col_names)}).set_index('#')
                            df_.index = df_.index.astype(int)
                            dfs[i] = df_


                    summary_cols = ['player','#','nation','pos','age','mins','goals','assists','pk_scored','pk_attempts','shots', 'shots_on_target','yellow_cards','red_cards','touches','pressures','tackles','interceptions','blocks','xg','npxG','xa','sca','gca','passes_completed','passes_attempted','pass_comp%','prog_pass_dist','carries','prog_carry_dist','dribbles_completed','dribbles_attempted']
                    passing_cols = ['player','#','nation','pos','age','mins','passes_completed','passes_attempted','pass_comp%','pass_dist','prog_pass_dist','short_passes_completed','short_passes_attempted','short_passes_comp%','med_passes_completed','med_passes_attempted','med_passes_comp%','long_passes_completed','long_passes_attempted','long_passes_comp%','assists','xa','key_pass','passes_into_final_3rd','passes_into_pa','crosses_into_pa','prog_passes']
                    pass_types_cols = ['player','#','nation','pos','age','mins','passes_attempted','live_passes','dead_passes','fk_passes','through_balls','pressured_passes','switches','crosses','corner_kicks','inswinging_corner_kicks','outswinging_corner_kicks','straight_corner_kicks','ground_passes','low_passes','high_passes','left_foot_passes','right_foot_passes','head_passes','throw-ins','body_passes','passes_completed','passes_offside','passes_oob','passes_intercepted','passes_blocked']
                    defensive_actions_cols = ['player','#','nation','pos','age','mins','tackles','tackles_won','def_3rd_tackles','mid_3rd_tackles','att_3rd_tackles','dribblers_tackled','dribbles_contested','dribblers_tackled%','dribbled_past_by_op','pressures','successful_pressures','successful_pressures%','def_3rd_pressures','mid_3rd_pressures', 'att_3rd_pressures','blocks','shots_blocked','shots_on_target_blocked','passes_blocked','interceptions','tackles+interceptions','clearances','errors_leading_to_shot']
                    possession_cols = ['player','#','nation','pos','age','mins','touches','def_pen_touches','def_3rd_touches','mid_3rd_touches','att_3rd_touches','att_pen_touches','live_touches','successful_dribbles','dribbles_attempted','successful_dribbles%','players_dribbled_past','nutmegs','carries','carry_dist','prog_carry_dist','pass_targets','passes_recieved','passes_recieved%','miscontrols','dispossessed']
                    misc_cols = ['player','#','nation','pos','age','mins','yellow_cards','red_cards','2nd_yellow_cards','fouls_committed','fouls_drawn','offsides','crosses','interceptions','tackles_won','pk_won','pk_conceded','own_goals','recoveries','aerials_won','aerials_lost','aerials_won%']
                    gk_cols = ['player','nation','age','mins','shots_on_target_against','goals_against','saves','save%','psxg','launch_completed','launch_attempted','launch_comp%','passes_completed','passes_attempted','pass_comp%','mean_pass_length','goal_kicks_attempted','goal_kicks_launch%','mean_goal_kick_dist','crosses_faced','crosses_stopped','crosses_stopped%','defensive_actions_outside_pa%', 'mean_defensive_action_dist']

                    # Reformat data to remove multi-indexing
                    reframe_squad_table([3,10], summary_cols)
                    reframe_squad_table([4,11], passing_cols)
                    reframe_squad_table([5,12], pass_types_cols)
                    reframe_squad_table([6,13], defensive_actions_cols)
                    reframe_squad_table([7,14], possession_cols)
                    reframe_squad_table([8,15], misc_cols)

                    # Reformat GKP data
                    for i in [9, 16]:
                        if len(dfs) > i:
                            df = dfs[i]
                            df = pd.DataFrame(data={col: df[df.columns[ii]] for ii, col in enumerate(gk_cols)})
                            dfs[i] = df

                    hdf = pd.concat(dfs[3:9], axis=1)
                    hdf = hdf.loc[:,~hdf.columns.duplicated()]

                    adf = pd.concat(dfs[10:16], axis=1)
                    adf = adf.loc[:,~adf.columns.duplicated()]


                    h_ppda = adf['passes_completed'].sum() / (hdf['tackles+interceptions'].sum() + hdf['passes_blocked'].sum())
                    a_ppda = hdf['passes_completed'].sum() / (adf['tackles+interceptions'].sum() + adf['passes_blocked'].sum())


                    h_match_stats = {}
                    h_match_stats['location'] = 'home'
                    h_match_stats['formation'] = formations[0]
                    h_match_stats['ppda'] = [h_ppda]
                    h_match_stats['possession'] = [dfs[2][teams[0]]['Possession'].loc[0]]
                    if len(dfs) > 16:
                        h_match_stats['psxg'] = [dfs[16]['psxg'].sum()]
                    for col in [i for i in hdf.columns if (i not in ['player', 'nation', 'pos', 'age', 'mins']) and ('%' not in i)]:
                        h_match_stats[col] = [hdf[col].sum()]
                    h_match_stats['ppda'] = [h_ppda]
                    h_match_stats['possession'] = [dfs[2][teams[0]]['Possession'].loc[0]]
                    h_match_df = pd.DataFrame.from_dict(h_match_stats).T
                    h_match_df.columns = [teams[0]]

                    a_match_stats = {}
                    a_match_stats['location'] = 'away'
                    a_match_stats['formation'] = formations[1]
                    a_match_stats['ppda'] = [a_ppda]
                    a_match_stats['possession'] = [dfs[2][teams[1]]['Possession'].loc[0]]
                    if len(dfs) > 16:
                        a_match_stats['psxg'] = [dfs[9]['psxg'].sum()]
                    for col in [i for i in hdf.columns if (i not in ['player', 'nation', 'pos', 'age', 'mins']) and ('%' not in i)]:
                        a_match_stats[col] = [adf[col].sum()]
                    a_match_df = pd.DataFrame.from_dict(a_match_stats).T
                    a_match_df.columns = [teams[1]]

                    match_df = pd.concat([h_match_df, a_match_df], axis=1).T


                    path = '{}/{}_data/{}_{}/{}'.format(cur_dir,league_name,str(season_index + 2017), str(season_index + 18),url.split('/')[-1].replace('-', '_'))[:-trim_len]
                    try:
                        os.mkdir(path)
                    except OSError:
                        print("Directory %s already exists" % path)
                    else:
                        print("Successfully created the directory %s " % path)
                    hdf.to_csv('{}/{}_player_stats.csv'.format(path, teams[0]))

                    dfs[0].to_csv('{}/{}_squad.csv'.format(path, teams[0]))
                    if len(dfs) > 16:
                        dfs[9].to_csv('{}/{}_gkp_stats.csv'.format(path, teams[0]))
                    adf.to_csv('{}/{}_player_stats.csv'.format(path, teams[1]))
                    match_df.to_csv('{}/match_stats.csv'.format(path))
                    dfs[1].to_csv('{}/{}_squad.csv'.format(path, teams[1]))
                    if len(dfs) > 16:
                        dfs[16].to_csv('{}/{}_gkp_stats.csv'.format(path, teams[1]))
                    hrefs.append(links['href'])
                    pickle_out = open(cur_dir + '/{}_data/hrefs.pickle'.format(league_name), 'wb')
                    pickle.dump(hrefs, pickle_out)
                    pickle_out.close()
                    time.sleep(0.1)
        print(str(season_index + 2017) + '/' + str(season_index + 18) + ' {} season import complete'.format(league_name))
    print('{} data import complete'.format(league_name))




def import_all():
    urls = [
        'https://fbref.com/en/comps/9/1631/schedule/2017-2018-Premier-League-Scores-and-Fixtures',
        'https://fbref.com/en/comps/9/1889/schedule/2018-2019-Premier-League-Scores-and-Fixtures',
        'https://fbref.com/en/comps/9/3232/schedule/2019-2020-Premier-League-Scores-and-Fixtures',
        'https://fbref.com/en/comps/9/10728/schedule/2020-2021-Premier-League-Scores-and-Fixtures',
        'https://fbref.com/en/comps/9/schedule/Premier-League-Scores-and-Fixtures',
    ]
    import_data('PL', urls, len('-Premier-League'))

     urls = [
         'https://fbref.com/en/comps/13/1632/schedule/2017-2018-Ligue-1-Scores-and-Fixtures',
         'https://fbref.com/en/comps/13/2104/schedule/2018-2019-Ligue-1-Scores-and-Fixtures',
         'https://fbref.com/en/comps/13/3243/schedule/2019-2020-Ligue-1-Scores-and-Fixtures',
         'https://fbref.com/en/comps/13/10732/schedule/2020-2021-Ligue-1-Scores-and-Fixtures',
         'https://fbref.com/en/comps/13/schedule/Ligue-1-Scores-and-Fixtures',
     ]
     import_data('Ligue_1', urls, len('-Ligue-1'))

    urls = [
        'https://fbref.com/en/comps/20/1634/schedule/2017-2018-Bundesliga-Scores-and-Fixtures',
        'https://fbref.com/en/comps/20/2109/schedule/2018-2019-Bundesliga-Scores-and-Fixtures',
        'https://fbref.com/en/comps/20/3248/schedule/2019-2020-Bundesliga-Scores-and-Fixtures',
        'https://fbref.com/en/comps/20/10737/schedule/2020-2021-Bundesliga-Scores-and-Fixtures',
        'https://fbref.com/en/comps/20/schedule/Bundesliga-Scores-and-Fixtures',
    ]
    import_data('Bundesliga', urls, len('-Bundesliga'))

    urls = [
        'https://fbref.com/en/comps/11/1640/schedule/2017-2018-Serie-A-Scores-and-Fixtures',
        'https://fbref.com/en/comps/11/1896/schedule/2018-2019-Serie-A-Scores-and-Fixtures',
        'https://fbref.com/en/comps/11/3260/schedule/2019-2020-Serie-A-Scores-and-Fixtures',
        'https://fbref.com/en/comps/11/10730/schedule/2020-2021-Serie-A-Scores-and-Fixtures',
        'https://fbref.com/en/comps/11/schedule/Serie-A-Scores-and-Fixtures',
    ]
    import_data('Serie_A', urls, len('-Serie-A'))

    urls = [
        'https://fbref.com/en/comps/12/1652/schedule/2017-2018-La-Liga-Scores-and-Fixtures',
        'https://fbref.com/en/comps/12/1886/schedule/2018-2019-La-Liga-Scores-and-Fixtures',
        'https://fbref.com/en/comps/12/3239/schedule/2019-2020-La-Liga-Scores-and-Fixtures',
        'https://fbref.com/en/comps/12/10731/schedule/2020-2021-La-Liga-Scores-and-Fixtures',
        'https://fbref.com/en/comps/12/schedule/La-Liga-Scores-and-Fixtures',
    ]
    import_data('La_Liga', urls, len('-La-Liga'))