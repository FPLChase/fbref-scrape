from match_level_fbref_scrape_all import import_all
from reformat_csv import reformat

import_all()
reformat()