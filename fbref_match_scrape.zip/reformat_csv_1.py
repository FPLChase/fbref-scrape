import pandas as pd
import os
from itertools import product
from datetime import datetime
leagues, seasons = ['PL'
], ['2017_18', '2018_19', '2019_20', '2020_21','2021_22']
pd.set_option('display.width', 10000)
pd.set_option('display.max_columns', 100)
root_dir = os.getcwd()

def reformat():
    for league in leagues:
        dfs = []

        for season in seasons:
            season_dir = '{}/{}_data/{}'.format(root_dir, league, season)

            for match_dir, dirs, files in os.walk(season_dir):
                match_dir_name = match_dir
                if league == 'PL':
                    if match_dir.endswith('_Premier_League'):
                        match_dir = match_dir[:-(len('_Premier_League'))]
                elif match_dir.endswith('_{}'.format(league)):
                    match_dir = match_dir[:-(len(league) + 1)]
                if not match_dir.endswith(season):

                    month, day, year = match_dir.split('_')[-3:]

                    match_df = pd.read_csv(match_dir_name + '/match_stats.csv', index_col=0)
                    h_team, a_team = match_df.index[0], match_df.index[1]
                    h_df = pd.read_csv('{}/{}_player_stats.csv'.format(match_dir_name, h_team), index_col=0)
                    a_df = pd.read_csv('{}/{}_player_stats.csv'.format(match_dir_name, a_team), index_col=0)

                    def add_cols(df, location, team, opponent, day, month, year):
                        length = len(df)
                        df['location'] = [location] * length
                        df['team'] = [team] * length
                        df['opponent'] = [opponent] * length
                        date_time_str = '{} {} {}'.format('0{}'.format(day)[-2:], month, year)
                        date_time = datetime.strptime(date_time_str, '%d %B %Y')
                        df['date'] = date_time.date()
                        df = df[('player	nation	pos	age' + '\t' + 'location	team	opponent	date	mins	goals	assists	pk_scored	pk_attempts	shots	shots_on_target	yellow_cards	red_cards	touches	pressures	tackles	interceptions	blocks	xg	npxG	xa	sca	gca	passes_completed	passes_attempted	pass_comp%	prog_pass_dist	carries	prog_carry_dist	dribbles_completed	dribbles_attempted	pass_dist	short_passes_completed	short_passes_attempted	short_passes_comp%	med_passes_completed	med_passes_attempted	med_passes_comp%	long_passes_completed	long_passes_attempted	long_passes_comp%	key_pass	passes_into_final_3rd	passes_into_pa	crosses_into_pa	prog_passes	live_passes	dead_passes	fk_passes	through_balls	pressured_passes	switches	crosses	corner_kicks	inswinging_corner_kicks	outswinging_corner_kicks	straight_corner_kicks	ground_passes	low_passes	high_passes	left_foot_passes	right_foot_passes	head_passes	throw-ins	body_passes	passes_offside	passes_oob	passes_intercepted	passes_blocked	tackles_won	def_3rd_tackles	mid_3rd_tackles	att_3rd_tackles	dribblers_tackled	dribbles_contested	dribblers_tackled%	dribbled_past_by_op	successful_pressures	successful_pressures%	def_3rd_pressures	mid_3rd_pressures	att_3rd_pressures	shots_blocked	shots_on_target_blocked	tackles+interceptions	clearances	errors_leading_to_shot	def_pen_touches	def_3rd_touches	mid_3rd_touches	att_3rd_touches	att_pen_touches	live_touches	successful_dribbles	successful_dribbles%	players_dribbled_past	nutmegs	carry_dist	pass_targets	passes_recieved	passes_recieved%	miscontrols	dispossessed	2nd_yellow_cards	fouls_committed	fouls_drawn	offsides	pk_won	pk_conceded	own_goals	recoveries	aerials_won	aerials_lost	aerials_won%').split('\t')]
                        df = df.rename(columns={'npxG': 'npxg'})

                        return df

                    h_df = add_cols(h_df, location='h', team=h_team, opponent=a_team, day=day, month=month, year=year)
                    a_df = add_cols(a_df, location='a', team=a_team, opponent=h_team, day=day, month=month, year=year)
                    dfs.append(h_df)
                    dfs.append(a_df)

                    date_time_str = '{} {} {}'.format('0{}'.format(day)[-2:], month, year)
                    date_time = datetime.strptime(date_time_str, '%d %B %Y')
                    print('{} vs {} {} appended'.format(h_team, a_team, date_time.date()))

        df = pd.concat(dfs)

        df.to_csv('{}_data.csv'.format(league))